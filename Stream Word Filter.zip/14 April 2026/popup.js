// Complete popup.js - Streaming Service Word Filter
// Version 2.0 - Fixed Preset Lists and Mission Page

// Preset word lists (matching content.js)
const presetWordLists = {
    profanity: [
        "damn", "hell", "crap", "ass"
    ],
    strong_profanity: [
        "fuck", "shit", "bitch"
    ],
    blasphemous: [
        "jesus", "christ", "oh my god"
    ],
    mild_profanity: [
        "damn", "crap", "piss", "sucks"
    ]
};

// DOM elements
let powerToggle, overlayColor, overlayOpacity, opacityValue, duration;
let newWordInput, addWordBtn, wordList;
let captionNotifications;
let tabStatus, tabStatusText, platformStatus, platformText;
let captionBadge, captionDetails, enableCaptionsBtn;
let wordsFilteredSpan, totalFiltersSpan;
let reviewBanner, reviewBtn, reviewDismissBtn;

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
    initializeElements();
    await loadSettings();
    await loadGlobalStats();
    await updateStatus();
    setupEventListeners();

    // Show review prompt if the user has filtered enough words and not already dismissed
    maybeShowReviewBanner();

    // Set up periodic status updates
    setInterval(updateStatus, 2000);
});

function initializeElements() {
    // Power and settings
    powerToggle = document.getElementById('powerToggle');
    overlayColor = document.getElementById('overlayColor');
    overlayOpacity = document.getElementById('overlayOpacity');
    opacityValue = document.getElementById('opacityValue');
    duration = document.getElementById('duration');
    captionNotifications = document.getElementById('captionNotifications');

    // Word management
    newWordInput = document.getElementById('newWord');
    addWordBtn = document.getElementById('addWord');
    wordList = document.getElementById('wordList');

    // Status elements
    tabStatus = document.getElementById('tabStatus');
    tabStatusText = document.getElementById('tabStatusText');
    platformStatus = document.getElementById('platformStatus');
    platformText = document.getElementById('platformText');

    // Caption elements
    captionBadge = document.getElementById('captionBadge');
    captionDetails = document.getElementById('captionDetails');
    enableCaptionsBtn = document.getElementById('enableCaptionsBtn');

    // Stats elements
    wordsFilteredSpan = document.getElementById('wordsFiltered');
    totalFiltersSpan = document.getElementById('totalFilters');

    // Review prompt elements
    reviewBanner = document.getElementById('reviewBanner');
    reviewBtn = document.getElementById('reviewBtn');
    reviewDismissBtn = document.getElementById('reviewDismissBtn');
}

async function loadSettings() {
    return new Promise((resolve) => {
        chrome.storage.sync.get([
            'words', 'duration', 'color', 'opacity', 'enabled', 'captionNotifications'
        ], (result) => {
            // Load power toggle
            powerToggle.checked = result.enabled !== false;

            // Load overlay settings
            overlayColor.value = result.color || '#000000';
            overlayOpacity.value = (result.opacity !== undefined ? result.opacity : 1) * 100;
            opacityValue.textContent = Math.round((result.opacity !== undefined ? result.opacity : 1) * 100) + '%';

            // Load duration
            duration.value = result.duration || 2;

            // Load notification settings
            captionNotifications.checked = result.captionNotifications !== false;

            // Load words
            updateWordList(result.words || []);

            resolve();
        });
    });
}

function setupEventListeners() {
    // Power toggle
    powerToggle.addEventListener('change', (e) => {
        const enabled = e.target.checked;
        chrome.storage.sync.set({ enabled: enabled });

        // Notify content script
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'toggleEnabled',
                    enabled: enabled
                }).catch(() => {
                    // Content script might not be loaded
                });
            }
        });
    });

    // Overlay color
    overlayColor.addEventListener('change', (e) => {
        chrome.storage.sync.set({ color: e.target.value });
    });

    // Overlay opacity
    overlayOpacity.addEventListener('input', (e) => {
        const opacity = e.target.value / 100;
        opacityValue.textContent = e.target.value + '%';
        chrome.storage.sync.set({ opacity: opacity });
    });

    // Duration
    duration.addEventListener('change', (e) => {
        const durationValue = parseInt(e.target.value);
        if (durationValue >= 1 && durationValue <= 30) {
            chrome.storage.sync.set({ duration: durationValue });
        }
    });

    // Caption notifications
    captionNotifications.addEventListener('change', (e) => {
        chrome.storage.sync.set({ captionNotifications: e.target.checked });
    });

    // Add word functionality
    addWordBtn.addEventListener('click', addWord);
    newWordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addWord();
        }
    });

    // Preset word list buttons
    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', handlePresetButtonClick);
    });

    // Enable captions button
    enableCaptionsBtn.addEventListener('click', enableCaptions);

    // Mission page button
    document.getElementById('openMissionPage').addEventListener('click', openMissionPage);

    // Word list delete buttons (using event delegation)
    wordList.addEventListener('click', (e) => {
        if (e.target.classList.contains('delete-word')) {
            const word = e.target.dataset.word;
            if (word) {
                deleteWord(word);
            }
        }
    });

    // Review prompt handlers
    if (reviewBtn) {
        reviewBtn.addEventListener('click', () => {
            // Opens the Chrome Web Store listing review page in a new tab
            chrome.tabs.create({
                url: 'https://chromewebstore.google.com/detail/streaming-service-word-fi/fpdahjohhcohefpobeiojeckjdadgodp/reviews'
            });
            // Mark as dismissed so it doesn't reappear
            chrome.storage.sync.set({ reviewPromptDismissed: true });
            hideReviewBanner();
        });
    }
    if (reviewDismissBtn) {
        reviewDismissBtn.addEventListener('click', () => {
            chrome.storage.sync.set({ reviewPromptDismissed: true });
            hideReviewBanner();
        });
    }
}

// Load persisted filter stats from chrome.storage.local
async function loadGlobalStats() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['globalStats'], (result) => {
            const stats = result.globalStats || { totalWordsFiltered: 0, totalFiltersApplied: 0 };
            if (wordsFilteredSpan) {
                wordsFilteredSpan.textContent = stats.totalWordsFiltered || 0;
            }
            if (totalFiltersSpan) {
                totalFiltersSpan.textContent = stats.totalFiltersApplied || 0;
            }
            resolve();
        });
    });
}

// Review banner helpers
const REVIEW_THRESHOLD = 5; // Show review prompt after this many filter events

function showReviewBanner() {
    if (reviewBanner) reviewBanner.classList.add('show');
}

function hideReviewBanner() {
    if (reviewBanner) reviewBanner.classList.remove('show');
}

function maybeShowReviewBanner() {
    chrome.storage.sync.get(['reviewPromptDismissed'], (syncResult) => {
        if (syncResult.reviewPromptDismissed) return;
        chrome.storage.local.get(['globalStats'], (localResult) => {
            const stats = localResult.globalStats || { totalFiltersApplied: 0 };
            if ((stats.totalFiltersApplied || 0) >= REVIEW_THRESHOLD) {
                showReviewBanner();
            }
        });
    });
}

function handlePresetButtonClick(e) {
    const category = e.target.dataset.category;
    const action = e.target.dataset.action;

    if (action === 'clear') {
        // Clear all words
        if (confirm('Are you sure you want to clear all filtered words?')) {
            chrome.storage.sync.set({ words: [] }, () => {
                updateWordList([]);
                console.log('All filter words cleared');
            });
        }
    } else if (category && presetWordLists[category]) {
        // Add preset words
        addPresetWords(category, e.target);
    }
}

function addPresetWords(category, buttonElement) {
    const presetWords = presetWordLists[category] || [];

    chrome.storage.sync.get(['words'], (result) => {
        const currentWords = result.words || [];

        // Merge preset words with current words (avoid duplicates)
        const newWords = [...new Set([...currentWords, ...presetWords])];

        chrome.storage.sync.set({ words: newWords }, () => {
            updateWordList(newWords);
            console.log(`Added ${category} preset words:`, presetWords);

            // Show user feedback
            if (buttonElement) {
                const originalText = buttonElement.textContent;
                buttonElement.style.background = '#10b981';
                buttonElement.style.color = 'white';
                buttonElement.textContent = 'Added!';

                setTimeout(() => {
                    buttonElement.style.background = '';
                    buttonElement.style.color = '';
                    buttonElement.textContent = originalText;
                }, 1500);
            }
        });
    });
}

function addWord() {
    const word = newWordInput.value.trim().toLowerCase();
    if (!word) return;

    chrome.storage.sync.get(['words'], (result) => {
        const words = result.words || [];
        if (!words.includes(word)) {
            words.push(word);
            chrome.storage.sync.set({ words: words }, () => {
                updateWordList(words);
                newWordInput.value = '';
            });
        } else {
            // Word already exists - show feedback
            newWordInput.style.borderColor = '#f59e0b';
            setTimeout(() => {
                newWordInput.style.borderColor = '';
            }, 1000);
        }
    });
}

function deleteWord(word) {
    chrome.storage.sync.get(['words'], (result) => {
        const words = result.words || [];
        const filteredWords = words.filter(w => w !== word);
        chrome.storage.sync.set({ words: filteredWords }, () => {
            updateWordList(filteredWords);
        });
    });
}

function updateWordList(words) {
    if (!words || words.length === 0) {
        wordList.innerHTML = '<div class="empty-state">No filtered words yet</div>';
        return;
    }

    wordList.innerHTML = words.map(word => `
        <div class="word-item">
            <span class="word-text">${escapeHtml(word)}</span>
            <button class="delete-word" data-word="${escapeHtml(word)}" aria-label="Delete word">×</button>
        </div>
    `).join('');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function updateStatus() {
    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs[0];

        if (!tab) {
            updateStatusUI('No Active Tab', 'Not Detected', 'inactive', 'inactive');
            return;
        }

        // Check if it's a supported streaming site
        const supportedSites = [
            'netflix.com', 'disneyplus.com', 'amazon.com', 'amazon.co', 'primevideo.com',
            'hulu.com', 'hbomax.com', 'max.com', 'youtube.com', 'peacocktv.com',
            'paramountplus.com', 'showmax.com'
        ];

        const isSupported = supportedSites.some(site => tab.url.includes(site));

        if (!isSupported) {
            updateStatusUI('Unsupported Site', 'Not Supported', 'inactive', 'inactive');
            updateCaptionStatus('unknown', 'This site is not supported');
            return;
        }

        // Try to get status from content script
        chrome.tabs.sendMessage(tab.id, { action: 'getStatus' }, (response) => {
            if (chrome.runtime.lastError || !response) {
                updateStatusUI('Script Not Loaded', 'Detected', 'error', 'warning');
                updateCaptionStatus('unknown', 'Content script not loaded');
                return;
            }

            // Update status
            updateStatusUI('Active', response.platform || 'Unknown', 'active', 'active');

            // Update caption status
            if (response.captions) {
                updateCaptionStatus(response.captions.status,
                    response.captions.message || response.captions.language || 'Active');
            }

            // Stats are now sourced from chrome.storage.local (globalStats),
            // not from the per-tab content script. We skip stats here.
        });

    } catch (error) {
        console.error('Status update failed:', error);
        updateStatusUI('Error', 'Error', 'error', 'error');
    }
}

function updateStatusUI(tabStatusMsg, platformMsg, tabStatusClass, platformStatusClass) {
    tabStatusText.textContent = tabStatusMsg;
    platformText.textContent = platformMsg;

    // Update status indicators
    tabStatus.className = `status-indicator ${tabStatusClass}`;
    platformStatus.className = `status-indicator ${platformStatusClass}`;
}

function updateCaptionStatus(status, details) {
    // Update badge
    captionBadge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    captionBadge.className = `caption-status-badge ${status}`;

    // Update details
    captionDetails.textContent = details;

    // Show/hide enable button
    if (status === 'disabled') {
        enableCaptionsBtn.classList.add('show');
    } else {
        enableCaptionsBtn.classList.remove('show');
    }
}

function enableCaptions() {
    enableCaptionsBtn.disabled = true;
    enableCaptionsBtn.textContent = 'Enabling...';

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'enableCaptions' }, (response) => {
                enableCaptionsBtn.disabled = false;
                enableCaptionsBtn.textContent = 'Enable Captions';

                if (chrome.runtime.lastError) {
                    console.error('Failed to enable captions:', chrome.runtime.lastError.message);
                    return;
                }

                if (response && response.success) {
                    updateCaptionStatus('enabled', 'Captions enabled successfully');
                    enableCaptionsBtn.classList.remove('show');
                } else {
                    console.error('Failed to enable captions:', response?.error || 'Unknown error');
                }
            });
        }
    });
}

function openMissionPage() {
    chrome.tabs.create({
        url: chrome.runtime.getURL('mission.html')
    });
}

// Message listener for real-time updates
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateCounts') {
        if (message.wordsFiltered !== undefined) {
            wordsFilteredSpan.textContent = message.wordsFiltered;
        }
        if (message.totalFilters !== undefined) {
            totalFiltersSpan.textContent = message.totalFilters;
        }
    }
});