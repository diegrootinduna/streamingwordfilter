﻿// Complete content.js - Streaming Service Word Filter with Caption Detection
// Version 2.0 - Enhanced Disney+ Support

const DEBUG = true; // Set to false in production

function log(...args) {
    if (DEBUG) console.log('[Word Filter]', ...args);
}

// Settings and state management
let settings = { words: [], duration: 2, color: '#4A1818', opacity: 1, enabled: true };
let hazeOverlay;
let timeoutId;
let originalMuted = false;
let isInitialized = false;
let isEffectActive = false;

// Platform detection
const isDisneyPlus = window.location.hostname.includes('disneyplus.com');
const isAmazonPrime = window.location.hostname.includes('amazon.com') ||
    window.location.hostname.includes('amazon.co') ||
    window.location.hostname.includes('primevideo.com');
const isNetflix = window.location.hostname.includes('netflix.com');
const isHulu = window.location.hostname.includes('hulu.com');
const isHBOMax = window.location.hostname.includes('hbomax.com') ||
    window.location.hostname.includes('max.com');
const isYouTube = window.location.hostname.includes('youtube.com');
const isPeacock = window.location.hostname.includes('peacocktv.com');
const isParamount = window.location.hostname.includes('paramountplus.com');
const isShowmax = window.location.hostname.includes('showmax.com');
// Preset word lists (you can populate these as needed)
const presetWordLists = {
    profanity: [
        "damn", "hell", "crap", "ass",
        // Add more as needed - keeping examples minimal
    ],

    strong_profanity: [
        "fuck", "shit", "bitch",
        // Add stronger words as needed
    ],

    blasphemous: ["jesus", "christ", "oh my god"
        // Add religious terms you want to filter
        // Examples: taking deity names in vain, etc.
    ],

    mild_profanity: [
        "damn", "crap", "piss", "sucks"
    ],

    // Custom categories
    custom_filter_1: [
        // Your custom words here
    ]
};

// Function to get preset word list
function getPresetWordList(category) {
    return presetWordLists[category] || [];
}

// Function to add preset list to current words
function addPresetWords(category) {
    const presetWords = getPresetWordList(category);

    chrome.storage.sync.get(['words'], (result) => {
        const currentWords = result.words || [];

        // Merge preset words with current words (avoid duplicates)
        const newWords = [...new Set([...currentWords, ...presetWords])];

        chrome.storage.sync.set({ words: newWords }, () => {
            console.log(`Added ${category} preset words:`, presetWords);

            // Notify content script about update
            chrome.runtime.sendMessage({
                action: 'wordsUpdated',
                words: newWords
            });
        });
    });
}

// Function to clear all words
function clearAllWords() {
    chrome.storage.sync.set({ words: [] }, () => {
        console.log('All filter words cleared');
    });
}
// Statistics tracking
let stats = {
    wordsFiltered: 0,
    totalFilters: 0,
    sessionStart: Date.now()
};

// Caption Detection System
class CaptionDetector {
    constructor() {
        this.platform = this.detectPlatform();
        this.lastStatus = null;
        this.checkInterval = null;
    }

    detectPlatform() {
        const hostname = window.location.hostname;
        // Check more specific domains first to avoid conflicts
        if (hostname.includes('showmax.com')) return 'Showmax';
        if (hostname.includes('netflix.com')) return 'Netflix';
        if (hostname.includes('disneyplus.com')) return 'Disney+';
        if (hostname.includes('amazon.com') || hostname.includes('primevideo.com')) return 'Amazon Prime';
        if (hostname.includes('hulu.com')) return 'Hulu';
        if (hostname.includes('hbomax.com') || hostname.includes('max.com')) return 'HBO Max';
        if (hostname.includes('youtube.com')) return 'YouTube';
        if (hostname.includes('peacocktv.com')) return 'Peacock';
        if (hostname.includes('paramountplus.com')) return 'Paramount+';
        return 'Unknown';
    }

    async detectCaptionStatus() {
        const detectors = {
            'Netflix': this.detectNetflixCaptions,
            'Disney+': this.detectDisneyPlusCaptions,
            'Amazon Prime': this.detectAmazonCaptions,
            'YouTube': this.detectYouTubeCaptions,
            'Hulu': this.detectHuluCaptions,
            'HBO Max': this.detectHBOMaxCaptions,
            'Showmax': this.detectShowmaxCaptions
        };

        const detector = detectors[this.platform];
        if (detector) {
            return detector.call(this);
        }

        return {
            status: 'unknown',
            message: `Caption detection not available for ${this.platform}`
        };
    }

    detectNetflixCaptions() {
        const video = document.querySelector('video');
        if (video && video.textTracks) {
            for (let track of video.textTracks) {
                if ((track.kind === 'subtitles' || track.kind === 'captions') &&
                    track.mode === 'showing') {
                    return {
                        status: 'enabled',
                        language: track.label || 'Unknown Language',
                        method: 'textTrack'
                    };
                }
            }
        }

        const subtitleContainers = document.querySelectorAll(
            '.player-timedtext-text-container, .player-timedtext'
        );

        if (subtitleContainers.length > 0) {
            for (let container of subtitleContainers) {
                if (container.textContent.trim()) {
                    return {
                        status: 'enabled',
                        language: 'Unknown Language',
                        method: 'DOM'
                    };
                }
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    detectDisneyPlusCaptions() {
        // Enhanced Disney+ detection with multiple selectors
        const disneySelectors = [
            '.shaka-text-container',
            '.shaka-text-container span',
            '[class*="shaka"]',
            '.btm-media-overlays-container',
            '.btm-media-client-element',
            '[class*="subtitle"]',
            '[class*="caption"]',
            '[class*="text-track"]',
            '.video-player-subtitles',
            '.player-subtitles',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            '[class*="btm-"]',
            '[role="text"]'
        ];

        for (let selector of disneySelectors) {
            const elements = document.querySelectorAll(selector);
            for (let element of elements) {
                if (element.textContent.trim() &&
                    window.getComputedStyle(element).display !== 'none' &&
                    window.getComputedStyle(element).visibility !== 'hidden') {
                    return {
                        status: 'enabled',
                        language: 'Active',
                        method: 'DOM',
                        selector: selector
                    };
                }
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    detectAmazonCaptions() {
        const captionSelectors = [
            '.atvwebplayersdk-captions-text',
            '.captions-text',
            '[class*="captions"]:not([class*="button"])',
            '.subtitles'
        ];

        for (let selector of captionSelectors) {
            const elements = document.querySelectorAll(selector);
            for (let element of elements) {
                if (element.textContent.trim() &&
                    window.getComputedStyle(element).display !== 'none') {
                    return {
                        status: 'enabled',
                        language: 'Active',
                        method: 'DOM'
                    };
                }
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    detectYouTubeCaptions() {
        // Check for active caption elements (updated selectors for 2024/2025)
        const captionSelectors = [
            '.ytp-caption-window-container .captions-text',
            '.ytp-caption-segment',
            '.caption-window .captions-text',
            '.ytp-caption-window-container span[style*="color"]',
            '.html5-video-player .captions-text',
            '.caption-window'
        ];

        for (let selector of captionSelectors) {
            const elements = document.querySelectorAll(selector);
            for (let element of elements) {
                if (element.textContent.trim() &&
                    window.getComputedStyle(element).display !== 'none' &&
                    window.getComputedStyle(element).visibility !== 'hidden') {
                    return {
                        status: 'enabled',
                        language: 'Active',
                        method: 'DOM'
                    };
                }
            }
        }

        // Check CC button state as fallback
        const ccButton = document.querySelector('.ytp-subtitles-button');
        if (ccButton && ccButton.getAttribute('aria-pressed') === 'true') {
            return {
                status: 'enabled',
                language: 'Unknown Language',
                method: 'UI'
            };
        }

        return {
            status: 'disabled',
            message: 'Captions are off'
        };
    }

    detectShowmaxCaptions() {
        // Common Showmax caption selectors (may need adjustment based on actual DOM)
        const captionSelectors = [
            '.subtitle-container',
            '.subtitles',
            '.captions',
            '[class*="subtitle"]',
            '[class*="caption"]',
            '[class*="cc-"]',
            '.video-subtitle',
            '.player-subtitle',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            // Generic selectors for any streaming service
            '[role="text"][aria-live]',
            '.text-overlay',
            '.overlay-text'
        ];

        for (let selector of captionSelectors) {
            const elements = document.querySelectorAll(selector);
            for (let element of elements) {
                if (element.textContent.trim() &&
                    window.getComputedStyle(element).display !== 'none' &&
                    window.getComputedStyle(element).visibility !== 'hidden') {
                    return {
                        status: 'enabled',
                        language: 'Active',
                        method: 'DOM',
                        selector: selector
                    };
                }
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    detectHuluCaptions() {
        const captionContainers = document.querySelectorAll(
            '.closed-caption-container, .caption-text, [class*="ClosedCaption"]'
        );

        for (let container of captionContainers) {
            if (container.textContent.trim() &&
                window.getComputedStyle(container).display !== 'none') {
                return {
                    status: 'enabled',
                    language: 'Active',
                    method: 'DOM'
                };
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    detectHBOMaxCaptions() {
        const subtitleElements = document.querySelectorAll(
            '[class*="Subtitles"], .subtitle-container, [data-testid="subtitle"]'
        );

        for (let element of subtitleElements) {
            if (element.textContent.trim() &&
                window.getComputedStyle(element).display !== 'none') {
                return {
                    status: 'enabled',
                    language: 'Active',
                    method: 'DOM'
                };
            }
        }

        return {
            status: 'disabled',
            message: 'No active captions detected'
        };
    }

    async enableCaptions() {
        const enablers = {
            'Netflix': this.enableNetflixCaptions,
            'Disney+': this.enableDisneyPlusCaptions,
            'Amazon Prime': this.enableAmazonCaptions,
            'YouTube': this.enableYouTubeCaptions,
            'Hulu': this.enableHuluCaptions,
            'HBO Max': this.enableHBOMaxCaptions,
            'Showmax': this.enableShowmaxCaptions
        };

        const enabler = enablers[this.platform];
        if (enabler) {
            return await enabler.call(this);
        }

        return {
            success: false,
            error: `Cannot enable captions for ${this.platform}`
        };
    }

    async enableNetflixCaptions() {
        const subtitleButton = document.querySelector(
            'button[aria-label*="Subtitle"], button[aria-label*="subtitle"]'
        );

        if (subtitleButton) {
            subtitleButton.click();
            await this.sleep(1000);

            const subtitleOptions = document.querySelectorAll('[data-uia*="track-subtitle"]');
            if (subtitleOptions.length > 0) {
                subtitleOptions[0].click();
                return { success: true };
            }
        }

        return { success: false, error: 'Could not find subtitle controls' };
    }

    async enableDisneyPlusCaptions() {
        // Enhanced Disney+ caption enabling with multiple selectors
        const buttonSelectors = [
            'button[aria-label*="Subtitle"]',
            'button[data-testid="subtitles-button"]',
            'button[aria-label*="Caption"]',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            '.subtitle-button',
            '.caption-button',
            '[class*="subtitle-toggle"]',
            'button[class*="btm-"]'
        ];

        for (let selector of buttonSelectors) {
            const button = document.querySelector(selector);
            if (button) {
                log('Found Disney+ subtitle button:', selector);
                button.click();
                await this.sleep(1500); // Give Disney+ more time

                // Look for subtitle options with multiple selectors
                const optionSelectors = [
                    '[role="menuitemradio"]',
                    '[role="option"]',
                    '[data-testid*="english"]',
                    '[data-testid*="subtitle-track"]',
                    '.subtitle-option',
                    '.caption-option'
                ];

                for (let optionSelector of optionSelectors) {
                    const options = document.querySelectorAll(optionSelector);
                    for (let option of options) {
                        const text = option.textContent.toLowerCase();
                        if (!text.includes('off') && !text.includes('none') &&
                            (text.includes('english') || text.includes('subtitle') || text.includes('caption'))) {
                            option.click();
                            log('Clicked Disney+ subtitle option:', text);
                            return { success: true };
                        }
                    }
                }
            }
        }

        return { success: false, error: 'Could not find or enable Disney+ subtitle controls' };
    }

    async enableAmazonCaptions() {
        const button = document.querySelector(
            '.atvwebplayersdk-subtitles-button, button[aria-label*="Subtitle"]'
        );

        if (button) {
            button.click();
            await this.sleep(1000);

            const options = document.querySelectorAll('[role="menuitem"]');
            for (let option of options) {
                const text = option.textContent.toLowerCase();
                if (text.includes('english') || (text.includes('subtitle') && !text.includes('off'))) {
                    option.click();
                    return { success: true };
                }
            }
        }

        return { success: false, error: 'Could not enable captions' };
    }

    async enableYouTubeCaptions() {
        const ccButton = document.querySelector('.ytp-subtitles-button');
        if (ccButton && ccButton.getAttribute('aria-pressed') === 'false') {
            ccButton.click();
            return { success: true };
        }
        return { success: false, error: 'Captions already enabled or button not found' };
    }

    async enableShowmaxCaptions() {
        // Common subtitle button selectors for Showmax
        const subtitleButtonSelectors = [
            'button[aria-label*="Subtitle"]',
            'button[aria-label*="subtitle"]',
            'button[aria-label*="Caption"]',
            'button[aria-label*="caption"]',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            '.subtitle-button',
            '.caption-button',
            '.cc-button',
            '[class*="subtitle-toggle"]',
            '[class*="caption-toggle"]'
        ];

        for (let selector of subtitleButtonSelectors) {
            const button = document.querySelector(selector);
            if (button) {
                button.click();
                await this.sleep(1000);

                // Look for subtitle options
                const optionSelectors = [
                    '[role="menuitem"]',
                    '[role="option"]',
                    '.subtitle-option',
                    '.caption-option',
                    '[data-testid*="english"]',
                    '[data-testid*="subtitle-track"]'
                ];

                for (let optionSelector of optionSelectors) {
                    const options = document.querySelectorAll(optionSelector);
                    for (let option of options) {
                        const text = option.textContent.toLowerCase();
                        if ((text.includes('english') || text.includes('subtitle')) &&
                            !text.includes('off') && !text.includes('none')) {
                            option.click();
                            return { success: true };
                        }
                    }
                }
            }
        }

        return { success: false, error: 'Could not find or enable Showmax subtitle controls' };
    }

    async enableHuluCaptions() {
        const button = document.querySelector('button[aria-label*="Closed Captions"]');
        if (button) {
            button.click();
            await this.sleep(500);
            const englishOption = document.querySelector('[data-testid*="english"]');
            if (englishOption) {
                englishOption.click();
                return { success: true };
            }
        }
        return { success: false, error: 'Could not enable captions' };
    }

    async enableHBOMaxCaptions() {
        const button = document.querySelector('button[aria-label*="Subtitles"]');
        if (button) {
            button.click();
            await this.sleep(500);
            const englishOption = Array.from(document.querySelectorAll('[role="menuitemradio"]'))
                .find(el => el.textContent.includes('English'));
            if (englishOption) {
                englishOption.click();
                return { success: true };
            }
        }
        return { success: false, error: 'Could not enable captions' };
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Helper functions
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function extractSubtitleText(element) {
    let text = element.textContent.trim().toLowerCase();
    text = text.replace(/^\[.*?\]/, ''); // Remove [speaker] labels
    text = text.replace(/\(.*?\)/g, ''); // Remove (sound descriptions)
    text = text.replace(/♪.*?♪/g, ''); // Remove music notations
    return text.trim();
}

function containsFilteredWord(text, words) {
    for (const word of words) {
        const regex = new RegExp(`\\b${escapeRegex(word)}\\b`, 'i');
        if (regex.test(text)) {
            return { found: true, word: word };
        }
    }
    return { found: false };
}

function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|\\]/g, '\\$&').replace(/\[/g, '\\[').replace(/\]/g, '\\]');
}

// Effect functions');


// Caption status notification
async function checkAndNotifyCaptionStatus() {
    // Check if notifications are enabled
    chrome.storage.sync.get(['captionNotifications'], async (result) => {
        const notificationsEnabled = result.captionNotifications !== false; // Default true

        if (!notificationsEnabled) {
            log('Caption notifications disabled by user');
            return;
        }

        // Wait a bit for the page to fully load
        await sleep(3000);

        try {
            const captionStatus = await captionDetector.detectCaptionStatus();
            log('Caption status check:', captionStatus);

            if (captionStatus.status === 'disabled') {
                showCaptionNotification();
            }
        } catch (error) {
            log('Caption status check failed:', error);
        }
    });
}

function showCaptionNotification() {
    // Send message to background script to show notification
    chrome.runtime.sendMessage({
        action: 'showCaptionNotification',
        platform: captionDetector.platform
    }, (response) => {
        if (chrome.runtime.lastError) {
            log('Failed to show notification:', chrome.runtime.lastError.message);
        } else {
            log('Caption notification shown');
        }
    });
}

// Effect functions
function applyEffects(matchedWord = null) {
    if (!settings.enabled) {
        log('Extension is disabled, skipping effects');
        return;
    }

    if (isEffectActive) {
        log('Effects already active, skipping...');
        return;
    }

    if (matchedWord) {
        stats.totalFilters++;
        stats.wordsFiltered++;
        updateStats();
    }

    const videos = document.querySelectorAll('video');
    const video = videos[0];

    if (videos.length > 0 && hazeOverlay) {
        isEffectActive = true;

        originalMuted = video.muted;
        const originalVolume = video.volume;
        video.dataset.originalVolume = originalVolume;

        if (isAmazonPrime) {
            document.querySelectorAll('video, audio').forEach(media => {
                media.dataset.originalMuted = media.muted;
                media.dataset.originalVolume = media.volume;
                media.muted = true;
                media.volume = 0;
            });
            log(`Muted ${videos.length} video elements and all audio elements`);

            const muteInterval = setInterval(() => {
                document.querySelectorAll('video, audio').forEach(media => {
                    media.muted = true;
                    media.volume = 0;
                });
            }, 50);

            video.dataset.muteInterval = muteInterval;
        } else if (isDisneyPlus) {
            video.muted = true;
            video.volume = 0;

            const muteInterval = setInterval(() => {
                video.muted = true;
                video.volume = 0;
            }, 100);

            video.dataset.muteInterval = muteInterval;
        } else {
            video.muted = true;
        }

        hazeOverlay.style.display = 'block';
        hazeOverlay.style.opacity = '0';
        requestAnimationFrame(() => {
            hazeOverlay.style.transition = 'opacity 0.2s ease-in';
            hazeOverlay.style.opacity = settings.opacity;
        });

        clearTimeout(timeoutId);
        timeoutId = setTimeout(removeEffects, settings.duration * 1000);

        log(`Effects applied for word: "${matchedWord}"`);
    }
}

function removeEffects() {
    const videos = document.querySelectorAll('video');

    if (videos.length > 0 && hazeOverlay) {
        isEffectActive = false;
        const video = videos[0];

        if (video.dataset.muteInterval) {
            clearInterval(video.dataset.muteInterval);
            delete video.dataset.muteInterval;
        }

        if (isAmazonPrime) {
            document.querySelectorAll('video, audio').forEach(media => {
                media.muted = media.dataset.originalMuted === 'true';
                media.volume = parseFloat(media.dataset.originalVolume) || 1;
                delete media.dataset.originalMuted;
                delete media.dataset.originalVolume;
            });
            log('Restored audio for all media elements');
        } else {
            video.muted = originalMuted;
            if (video.dataset.originalVolume) {
                video.volume = parseFloat(video.dataset.originalVolume);
                delete video.dataset.originalVolume;
            } else {
                video.volume = 1;
            }
        }

        hazeOverlay.style.transition = 'opacity 0.2s ease-out';
        hazeOverlay.style.opacity = '0';
        setTimeout(() => {
            hazeOverlay.style.display = 'none';
            hazeOverlay.style.transition = '';
        }, 200);

        log('Effects removed');
    }
}

// Monitoring functions
async function monitorNetflixSubtitles() {
    log('Starting Netflix subtitle monitoring...');

    await captionDetector.enableCaptions();

    const video = document.querySelector('video');
    let lastSubtitleText = '';

    if (video && video.textTracks && video.textTracks.length > 0) {
        const tracks = Array.from(video.textTracks);

        tracks.forEach((track, index) => {
            if ((track.kind === 'subtitles' || track.kind === 'captions') && track.mode === 'showing') {
                track.addEventListener('cuechange', () => {
                    const activeCues = track.activeCues;
                    if (activeCues && activeCues.length > 0) {
                        Array.from(activeCues).forEach(cue => {
                            const text = extractSubtitleText({ textContent: cue.text });
                            if (text && text !== lastSubtitleText) {
                                lastSubtitleText = text;
                                log('Netflix subtitle:', text);
                                const match = containsFilteredWord(text, settings.words);
                                if (match.found) {
                                    log('Word match found:', match.word);
                                    applyEffects(match.word);
                                }
                            }
                        });
                    }
                });
            }
        });
    }

    const checkDOMSubtitles = () => {
        const subtitleSelectors = [
            '.player-timedtext-text-container',
            '.player-timedtext',
            '[class*="player-timedtext"]'
        ];

        for (const selector of subtitleSelectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                const text = extractSubtitleText(element);
                if (text && text !== lastSubtitleText) {
                    lastSubtitleText = text;
                    log('Netflix subtitle (DOM):', text);
                    const match = containsFilteredWord(text, settings.words);
                    if (match.found) {
                        log('Word match found in DOM:', match.word);
                        applyEffects(match.word);
                    }
                }
            });
        }
    };

    setInterval(checkDOMSubtitles, 100);
}

async function monitorDisneyPlusSubtitles() {
    log('Starting Disney+ subtitle monitoring with enhanced detection...');

    // Give Disney+ more time to load
    await sleep(3000);

    // Try to enable captions but don't fail if it doesn't work
    try {
        await captionDetector.enableCaptions();
    } catch (error) {
        log('Disney+ caption enabling failed:', error);
    }

    let lastSubtitleText = '';
    let lastCheckTime = 0;

    const checkSubtitles = () => {
        const now = Date.now();
        if (now - lastCheckTime < 50) return;
        lastCheckTime = now;

        // Enhanced Disney+ selectors (updated for 2024/2025)
        const disneySelectors = [
            '.shaka-text-container',
            '.shaka-text-container span',
            // Additional selectors based on common Disney+ patterns
            '[class*="shaka"]',
            '.btm-media-overlays-container',
            '.btm-media-client-element',
            '[class*="subtitle"]',
            '[class*="caption"]',
            '[class*="text-track"]',
            '.video-player-subtitles',
            '.player-subtitles',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            // Generic fallbacks
            '[class*="btm-"]',
            '[role="text"]'
        ];

        let foundText = false;

        // Primary Shaka container check
        const subtitleContainers = document.querySelectorAll('.shaka-text-container');
        if (subtitleContainers.length > 0) {
            subtitleContainers.forEach(container => {
                const spans = container.querySelectorAll('span');
                let fullText = '';

                spans.forEach(span => {
                    const text = span.textContent.trim();
                    if (text) {
                        fullText += text + ' ';
                    }
                });

                fullText = extractSubtitleText({ textContent: fullText });

                if (fullText && fullText !== lastSubtitleText) {
                    foundText = true;
                    lastSubtitleText = fullText;
                    log('Disney+ subtitle (Shaka):', fullText);
                    const match = containsFilteredWord(fullText, settings.words);
                    if (match.found) {
                        log('Disney+ subtitle match found:', match.word);
                        applyEffects(match.word);
                    }
                }
            });
        }

        // Fallback selector check
        if (!foundText) {
            for (const selector of disneySelectors) {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    // Skip hidden elements
                    if (window.getComputedStyle(element).display === 'none') return;
                    if (window.getComputedStyle(element).visibility === 'hidden') return;

                    const text = extractSubtitleText(element);
                    if (text && text !== lastSubtitleText && text.length > 2) {
                        foundText = true;
                        lastSubtitleText = text;
                        log('Disney+ subtitle (fallback):', text, 'via selector:', selector);
                        const match = containsFilteredWord(text, settings.words);
                        if (match.found) {
                            log('Disney+ fallback match found:', match.word);
                            applyEffects(match.word);
                        }
                    }
                });

                if (foundText) break;
            }
        }
    };

    setInterval(checkSubtitles, 100);
    log('Disney+ subtitle monitoring started with enhanced selectors');
}

async function monitorAmazonPrimeSubtitles() {
    log('Starting Amazon Prime subtitle monitoring...');

    await captionDetector.enableCaptions();

    let lastSubtitleText = '';
    let lastCheckTime = 0;

    const checkSubtitles = () => {
        const now = Date.now();
        if (now - lastCheckTime < 50) return;
        lastCheckTime = now;

        const subtitleSelectors = [
            '.atvwebplayersdk-captions-text',
            '.captions-text',
            '[class*="captions"]',
            '.subtitles',
            '.atvwebplayersdk-subtitle-container span',
            '.f1qyoe4 span',
            'span[style*="font-family"][style*="font-size"]'
        ];

        let foundText = false;

        for (const selector of subtitleSelectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                const text = extractSubtitleText(element);
                if (text && text !== lastSubtitleText) {
                    foundText = true;
                    lastSubtitleText = text;
                    log('Amazon Prime subtitle:', text);
                    const match = containsFilteredWord(text, settings.words);
                    if (match.found) {
                        log('Amazon Prime subtitle match found:', match.word);
                        applyEffects(match.word);
                    }
                }
            });

            if (foundText) break;
        }
    };

    setInterval(checkSubtitles, 100);
}

// YouTube monitoring function
async function monitorYouTubeSubtitles() {
    log('Starting YouTube subtitle monitoring...');

    await captionDetector.enableCaptions();

    let lastSubtitleText = '';
    let lastCheckTime = 0;

    const checkSubtitles = () => {
        const now = Date.now();
        if (now - lastCheckTime < 50) return;
        lastCheckTime = now;

        // YouTube caption selectors (updated for 2024/2025)
        const subtitleSelectors = [
            '.ytp-caption-window-container .captions-text',
            '.ytp-caption-segment',
            '.caption-window .captions-text',
            '.ytp-caption-window-container span',
            '.html5-video-player .captions-text',
            '.caption-window'
        ];

        let foundText = false;

        for (const selector of subtitleSelectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Skip hidden elements
                if (window.getComputedStyle(element).display === 'none') return;

                const text = extractSubtitleText(element);
                if (text && text !== lastSubtitleText) {
                    foundText = true;
                    lastSubtitleText = text;
                    log('YouTube subtitle:', text);
                    const match = containsFilteredWord(text, settings.words);
                    if (match.found) {
                        log('YouTube subtitle match found:', match.word);
                        applyEffects(match.word);
                    }
                }
            });

            if (foundText) break;
        }
    };

    setInterval(checkSubtitles, 100);
}

// Showmax monitoring function
async function monitorShowmaxSubtitles() {
    log('Starting Showmax subtitle monitoring...');

    await captionDetector.enableCaptions();

    let lastSubtitleText = '';
    let lastCheckTime = 0;

    const checkSubtitles = () => {
        const now = Date.now();
        if (now - lastCheckTime < 50) return;
        lastCheckTime = now;

        // Showmax caption selectors (may need adjustment based on actual DOM)
        const subtitleSelectors = [
            '.subtitle-container',
            '.subtitles',
            '.captions',
            '[class*="subtitle"]',
            '[class*="caption"]',
            '[class*="cc-"]',
            '.video-subtitle',
            '.player-subtitle',
            '[data-testid*="subtitle"]',
            '[data-testid*="caption"]',
            '[role="text"][aria-live]',
            '.text-overlay',
            '.overlay-text'
        ];

        let foundText = false;

        for (const selector of subtitleSelectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Skip hidden elements
                if (window.getComputedStyle(element).display === 'none') return;
                if (window.getComputedStyle(element).visibility === 'hidden') return;

                const text = extractSubtitleText(element);
                if (text && text !== lastSubtitleText) {
                    foundText = true;
                    lastSubtitleText = text;
                    log('Showmax subtitle:', text);
                    const match = containsFilteredWord(text, settings.words);
                    if (match.found) {
                        log('Showmax subtitle match found:', match.word);
                        applyEffects(match.word);
                    }
                }
            });

            if (foundText) break;
        }
    };

    setInterval(checkSubtitles, 100);
}

// UI functions
function createHazeOverlay() {
    hazeOverlay = document.createElement('div');
    hazeOverlay.style.position = 'fixed';
    hazeOverlay.style.top = '0';
    hazeOverlay.style.left = '0';
    hazeOverlay.style.width = '100%';
    hazeOverlay.style.height = '100%';
    hazeOverlay.style.backgroundColor = settings.color;
    hazeOverlay.style.opacity = '0';
    hazeOverlay.style.display = 'none';
    hazeOverlay.style.zIndex = '999999';
    hazeOverlay.style.pointerEvents = 'none';
    document.body.appendChild(hazeOverlay);
    log('Haze overlay created');
}

function updateStats() {
    chrome.runtime.sendMessage({
        action: 'updateStats',
        stats: stats
    });
}

// Caption status notification
async function checkAndNotifyCaptionStatus() {
    // Wait a bit for the page to fully load
    await sleep(3000);

    try {
        const captionStatus = await captionDetector.detectCaptionStatus();
        log('Caption status check:', captionStatus);

        if (captionStatus.status === 'disabled') {
            showCaptionNotification();
        }
    } catch (error) {
        log('Caption status check failed:', error);
    }
}

function showCaptionNotification() {
    // Send message to background script to show notification
    chrome.runtime.sendMessage({
        action: 'showCaptionNotification',
        platform: captionDetector.platform
    }, (response) => {
        if (chrome.runtime.lastError) {
            log('Failed to show notification:', chrome.runtime.lastError.message);
        } else {
            log('Caption notification shown');
        }
    });
}

// Initialization
async function init() {
    if (isInitialized) {
        log('Already initialized, skipping...');
        return;
    }

    log('Initializing word filter on:', window.location.hostname);
    log('Filtered words:', settings.words);

    if (!hazeOverlay) {
        createHazeOverlay();
    }

    let retries = 0;
    const maxRetries = 10;

    const tryInit = async () => {
        const video = document.querySelector('video');
        if (video) {
            log('Video element found');
            isInitialized = true;

            await sleep(2000);

            // Check caption status and notify if disabled
            checkAndNotifyCaptionStatus();

            if (isNetflix) {
                log('Using Netflix monitoring with auto-caption');
                await monitorNetflixSubtitles();
            } else if (isDisneyPlus) {
                log('Using Disney+ monitoring with enhanced detection');
                await monitorDisneyPlusSubtitles();
            } else if (isAmazonPrime) {
                log('Using Amazon Prime monitoring with auto-caption');
                await monitorAmazonPrimeSubtitles();
            } else if (isYouTube) {
                log('Using YouTube monitoring with auto-caption');
                await monitorYouTubeSubtitles();
            } else if (isShowmax) {
                log('Using Showmax monitoring with auto-caption');
                await monitorShowmaxSubtitles();
            }
        } else if (retries < maxRetries) {
            retries++;
            log(`Video not found, retry ${retries}/${maxRetries}`);
            setTimeout(tryInit, 1500);
        } else {
            log('Max retries reached, giving up');
        }
    };

    tryInit();
}

// Initialize caption detector
const captionDetector = new CaptionDetector();

// Handle page navigation
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        log('URL changed, reinitializing...');
        isInitialized = false;
        if (hazeOverlay) {
            hazeOverlay.remove();
            hazeOverlay = null;
        }
        setTimeout(init, 1000);
    }
}).observe(document, { subtree: true, childList: true });

// Load settings and initialize
chrome.storage.sync.get(['words', 'duration', 'color', 'opacity', 'enabled'], (result) => {
    if (result.words) settings.words = result.words;
    if (result.duration) settings.duration = result.duration;
    if (result.color) settings.color = result.color;
    if (result.opacity !== undefined) settings.opacity = result.opacity;
    if (result.enabled !== undefined) settings.enabled = result.enabled;
    log('Settings loaded:', settings);
    init();
});

// Update settings when changed
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
        if (changes.words) settings.words = changes.words.newValue;
        if (changes.duration) settings.duration = changes.duration.newValue;
        if (changes.color) {
            settings.color = changes.color.newValue;
            if (hazeOverlay) hazeOverlay.style.backgroundColor = settings.color;
        }
        if (changes.opacity !== undefined) {
            settings.opacity = changes.opacity.newValue;
        }
        if (changes.enabled !== undefined) {
            settings.enabled = changes.enabled.newValue;
            log('Extension enabled state changed:', settings.enabled);
        }
        log('Settings updated:', settings);
    }
});

// Message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getStatus') {
        (async () => {
            const captionStatus = await captionDetector.detectCaptionStatus();
            sendResponse({
                captions: captionStatus,
                stats: {
                    wordsFiltered: stats.wordsFiltered || 0,
                    totalFilters: stats.totalFilters || 0
                },
                platform: captionDetector.platform,
                enabled: settings.enabled
            });
        })();
        return true;
    } else if (message.action === 'enableCaptions') {
        (async () => {
            const result = await captionDetector.enableCaptions();
            sendResponse(result);
        })();
        return true;
    } else if (message.action === 'toggleEnabled') {
        settings.enabled = message.enabled;
        log('Extension enabled state changed via popup:', settings.enabled);
        sendResponse({ success: true });
    } else if (message.action === 'ping') {
        sendResponse({ success: true });
    } else if (message.action === 'enableCaptionsFromNotification') {
        // Handle notification click to enable captions
        (async () => {
            log('Enabling captions from notification...');
            const result = await captionDetector.enableCaptions();
            if (result.success) {
                log('Captions enabled successfully from notification');
                // Show success notification
                chrome.runtime.sendMessage({
                    action: 'showSuccessNotification',
                    platform: captionDetector.platform
                });
            } else {
                log('Failed to enable captions from notification:', result.error);
                // Show failure notification
                chrome.runtime.sendMessage({
                    action: 'showFailureNotification',
                    platform: captionDetector.platform,
                    error: result.error
                });
            }
            sendResponse(result);
        })();
        return true;
    }
});