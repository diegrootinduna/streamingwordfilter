﻿// Complete background.js - Streaming Service Word Filter
// Version 2.0 - Service Worker Compatible

// Store statistics across sessions
let globalStats = {
    totalWordsFiltered: 0,
    totalFiltersApplied: 0,
    lastReset: Date.now()
};

// Load persisted stats on startup
chrome.storage.local.get(['globalStats'], (result) => {
    if (result.globalStats) {
        globalStats = result.globalStats;
    }
});

// Message handler
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateCounts') {
        // Forward the message to any open popups
        chrome.runtime.sendMessage(message).catch(() => {
            // Popup might be closed, ignore error
        });
    } else if (message.action === 'updateStats') {
        // Each updateStats message represents exactly one filter event.
        // Increment by 1 rather than adding the content script's running total
        // (which would cause double-counting as the total grows).
        globalStats.totalWordsFiltered += 1;
        globalStats.totalFiltersApplied += 1;

        // Save to persistent storage so the popup can read authoritative totals
        chrome.storage.local.set({ globalStats: globalStats });

        // Forward current totals to any open popup so the counter updates live
        chrome.runtime.sendMessage({
            action: 'updateCounts',
            wordsFiltered: globalStats.totalWordsFiltered,
            totalFilters: globalStats.totalFiltersApplied
        }).catch(() => {
            // Popup might not be open — this is expected, not an error
        });
    } else if (message.action === 'getGlobalStats') {
        sendResponse(globalStats);
    } else if (message.action === 'resetStats') {
        globalStats = {
            totalWordsFiltered: 0,
            totalFiltersApplied: 0,
            lastReset: Date.now()
        };
        chrome.storage.local.set({ globalStats: globalStats });
        sendResponse({ success: true });
    } else if (message.action === 'forceInject') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    files: ['content.js']
                }).then(() => {
                    sendResponse({ success: true });
                }).catch(err => {
                    sendResponse({ success: false, error: err.message });
                });
            }
        });
        return true; // Keep message channel open
    } else if (message.action === 'showCaptionNotification') {
        // Show notification when captions are disabled
        const platform = message.platform || 'this streaming service';
        chrome.notifications.create('captionsDisabled', {
            type: 'basic',
            iconUrl: 'icon128.png',
            title: 'Captions Not Enabled',
            message: `Captions are disabled on ${platform}. Click to enable them automatically.`,
            buttons: [
                { title: 'Enable Captions' },
                { title: 'Dismiss' }
            ],
            requireInteraction: true
        });
        sendResponse({ success: true });
    } else if (message.action === 'showSuccessNotification') {
        // Show success notification when captions are enabled
        const platform = message.platform || 'streaming service';
        chrome.notifications.create('captionsEnabled', {
            type: 'basic',
            iconUrl: 'icon128.png',
            title: 'Captions Enabled',
            message: `Captions have been successfully enabled on ${platform}.`,
            requireInteraction: false
        });
        sendResponse({ success: true });
    } else if (message.action === 'showFailureNotification') {
        // Show failure notification when caption enabling fails
        const platform = message.platform || 'streaming service';
        const error = message.error || 'Unknown error';
        chrome.notifications.create('captionsFailed', {
            type: 'basic',
            iconUrl: 'icon128.png',
            title: 'Failed to Enable Captions',
            message: `Could not automatically enable captions on ${platform}. Please enable them manually.`,
            requireInteraction: false
        });
        sendResponse({ success: true });
    }
});

// Listen for tab updates to inject content script if needed
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Check if this is a supported streaming site
        const supportedSites = [
            'netflix.com',
            'disneyplus.com',
            'amazon.com',
            'amazon.co',
            'primevideo.com',
            'hulu.com',
            'hbomax.com',
            'max.com',
            'youtube.com',
            'youtu.be',
            'm.youtube.com',
            'music.youtube.com',
            'peacocktv.com',
            'paramountplus.com',
            'showmax.com'
        ];

        const isSupported = supportedSites.some(site => tab.url.includes(site));

        if (isSupported) {
            // Try to send a ping to see if content script is already loaded
            chrome.tabs.sendMessage(tabId, { action: 'ping' }, (response) => {
                if (chrome.runtime.lastError || !response) {
                    // Content script not loaded, inject it
                    chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        files: ['content.js']
                    }).catch(err => {
                        console.log('Could not inject content script:', err);
                    });
                }
            });
        }
    }
});

// Set up alarm for periodic stats backup (every hour)
chrome.alarms.create('backupStats', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'backupStats') {
        chrome.storage.local.set({ globalStats: globalStats });
    }
});

// Context menu for quick word addition
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: 'addFilterWord',
        title: 'Add "%s" to filter list',
        contexts: ['selection']
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'addFilterWord' && info.selectionText) {
        const word = info.selectionText.trim().toLowerCase();

        chrome.storage.sync.get(['words'], (result) => {
            const words = result.words || [];
            if (!words.includes(word)) {
                words.push(word);
                chrome.storage.sync.set({ words: words }, () => {
                    // Notify user
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: 'icon128.png',
                        title: 'Word Added to Filter',
                        message: `"${word}" has been added to your filter list.`
                    });
                });
            }
        });
    }
});

// Handle notification clicks
chrome.notifications.onClicked.addListener((notificationId) => {
    if (notificationId === 'captionsDisabled') {
        // User clicked the main notification, treat as "Enable Captions"
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'enableCaptionsFromNotification'
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.log('Failed to enable captions:', chrome.runtime.lastError.message);
                    }
                });
            }
        });
        // Clear the notification
        chrome.notifications.clear(notificationId);
    }
});

// Handle notification button clicks
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (notificationId === 'captionsDisabled') {
        if (buttonIndex === 0) {
            // "Enable Captions" button clicked
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'enableCaptionsFromNotification'
                    }, (response) => {
                        if (chrome.runtime.lastError) {
                            console.log('Failed to enable captions:', chrome.runtime.lastError.message);
                        }
                    });
                }
            });
        }
        // Both "Enable Captions" and "Dismiss" clear the notification
        chrome.notifications.clear(notificationId);
    }
});

// Auto-clear notifications after a certain time
chrome.notifications.onClosed.addListener((notificationId, byUser) => {
    // Notification was closed, nothing special to do
    console.log(`Notification ${notificationId} closed by user: ${byUser}`);
});

// Initialize extension on install
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // Set default settings on first install
        // Open welcome page in a new tab on first install
        chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });

        chrome.storage.sync.get(['words', 'duration', 'color', 'opacity', 'enabled'], (result) => {
            const defaults = {
                words: result.words || [],
                duration: result.duration || 2,
                color: result.color || '#4A1818',
                opacity: result.opacity !== undefined ? result.opacity : 1.0,
                enabled: result.enabled !== undefined ? result.enabled : true
            };

            chrome.storage.sync.set(defaults, () => {
                console.log('Extension installed with default settings');
            });
        });
    } else if (details.reason === 'update') {
        // Handle updates if needed
        console.log('Extension updated to version', chrome.runtime.getManifest().version);
    }
});